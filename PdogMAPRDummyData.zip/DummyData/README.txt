This dummy data is entirely ficticious and is provided to allow users to explore the Prairie Dog MAPR 
in the absence of real data. Any outputs and results from these data do not necessarily represent how 
real colonies are composed or behave on the ground.

Two sets of dummy data are provided one for Thunder Basin and one for East 
Pawnee Grasslands. Each set includes four layers:

*Example_PdogColonies_CurrentYear - hypothetical prairie dog colonies mapped in the current year
*PawneeExample_PdogColonies_PriorYear  - hypothetical prairie dog colonies mapped in the prior year
*PawneeExample_PdogControl - areas of hypothetical prairie dog control measures
*PawneeExample_PlagueControl - areas of hypothetical plague control measures

To upload any of these layers in the app you will need to select all four associated files (.dbf, .prj, .shp, and .shx).


Happy exploring!

- the MAPR team